#Function to center data
center_methyln_data<-function(data,response){
	if (response=="M.value"){
		data[,"mean.response":=mean(M.value)]
		data[,"response.c":=M.value-mean.response,by=list(CpGname)]		
	}
	if (response=="beta.value"){
		data[,"mean.response":=mean(beta.value)]
		data[,"response.c":=beta.value-mean.response,by=list(CpGname)]

	}
return(data)
}


#Function to generate summary stats for a given dataset (based on mean-centered data)
generate_summary_stats<-function(data){
#Compute response-specific summary statistic - mean by cell type/CpG and sum of squares by CpG	
	#Sum of responses by cell type and CpG
	ybar.ct<-data[,list(ybar.ct=mean(response.c)),by=list(CpGname,cell.type)]
	ybar.ct<-dcast(ybar.ct,CpGname~cell.type,value.var="ybar.ct")

	#Sum of squared responses by CpG
	ss<-data[,list(ss=sum(response.c^2)),by=list(CpGname)]

	#Other summaries
	#Overall sample variance (for use in informative prior)
	sample.var<-data[,list(s2=var(response.c))]

	cell.types<-colnames(ybar.ct)[colnames(ybar.ct)!="CpGname"]
	CpG.list<-ybar.ct$CpGname
	N<-data[,list(N=length(unique(ID)))]
	output<-list(ybar.ct=ybar.ct,ss=ss$ss,sample.var=sample.var$s2,cell.types=cell.types,CpG.list=CpG.list,N=N$N)
	return(output)

}
#Function to compute R squared
compute_Rsq<-function(X,summary.stats){
#For each CpG, compute R-sq
svec<-as.matrix(summary.stats$ybar.ct[,-"CpGname",with=F])%*%X
Sigma<-solve(t(X)%*%X)
R.sq<-with(summary.stats,N*covmultiply(svec%*%Sigma,svec)/ss)
return(R.sq)
}
#Function to evaluate log ML for given stats and value of g (for use in EM)
compute_logML_EM<-function(X,N,ss,R.sq,g,indices){
	logML<-(-0.5)*ncol(X)*log(1+g)-0.5*N*indices$J*log(ss*(1-g*R.sq/(1+g)))
	return(logML)
}
#Compute log ML for sex dependent model
compute_logML_EM_dep<-function(X,N,g.1,g.2,ss.1,ss.2,g.Rsq.1,g.Rsq.2,indices){
	logML<-(-0.5)*ncol(X)*(log(1+g.1)+log(1+g.2))-0.5*N*indices$J*log(ss.1*g.Rsq.1+ss.2*g.Rsq.2)
	return(logML)
}

#Function to compute model based least squares estimate

compute_beta_post<-function(summary.stats,X,g,J){
beta.hat<-(0.5+as.matrix(summary.stats$ybar.ct[,-"CpGname",with=F]))%*%X%*%solve(t(X)%*%X)
rownames(beta.hat)<-summary.stats$CpG.list
mean.est<-melt(g*beta.hat/(1+g),value.name="mean.estimate",varnames=c("CpGname","partition"))
R.sq<-compute_Rsq(X,summary.stats)
sigma2.hat<-0.5*summary.stats$ss*(1-g*R.sq/(1+g))/(0.5*summary.stats$N*J-1)
var.est<-(g/(1+g))*(matrix(rep(sigma2.hat,each=ncol(X)),ncol=ncol(X),byrow=T)/summary.stats$N)%*%solve(t(X)%*%X)
rownames(var.est)<-summary.stats$CpG.list
var.est<-melt(var.est,value.name="var.estimate",varnames=c("CpGname","partition"))

out<-data.table(join(mean.est,var.est,by=c("CpGname","partition")))
setnames(out,c(3,4),c("mean.estimate","var.estimate"))
return(out)
}

#Function to compute moments of posterior predictive distribution, for a given dataset
#based on centered data!
compute_post_pred_moments<-function(summary.stats,X,g){
#compute posterior expectation
beta.hat<-(g/(1+g))*(as.matrix(summary.stats$ybar.ct[,-"CpGname",with=F]))%*%X%*%solve(t(X)%*%X)
rownames(beta.hat)<-summary.stats$CpG.list
Sigma<-(g/(1+g))*solve(t(X)%*%X)/summary.stats$N
R.sq<-compute_Rsq(X,summary.stats)
#Find posterior mean of sigma2 (sigma2.hat)
sigma2.hat<-0.5*summary.stats$ss*(1-g*R.sq/(1+g))/(0.5*summary.stats$N*length(summary.stats$cell.types)-1)
rownames(beta.hat)<-names(sigma2.hat)<-summary.stats$CpG.list
X.beta.hat<-X%*%t(beta.hat)
rownames(X.beta.hat)<-paste0(summary.stats$cell.types,".estimate")
#Reorder CpGs to match validation data

out<-setDT(data.frame(t(X.beta.hat),sigma2=sigma2.hat),keep.rownames=T)
setnames(out,"rn","CpGname")
return(list(out,Sigma))
}


compute_modelprobs_globalEB<-function(model.weights,model,summary.stats,g.start,indices,max.iter){
g<-g.start
prior.weights<-matrix(rep(model.weights,each=indices$K),nrow=indices$K)
R.sq<-sapply(1:indices$M,function(m) compute_Rsq(model[[m]],summary.stats))
pm<-sapply(1:indices$M,function(m) ncol(model[[m]]))
for (t in 1:max.iter){
g.R.sq<-1-(g/(1+g))*R.sq
logML<-log(prior.weights)+sapply(1:indices$M, function(m) compute_logML_EM(model[[m]],summary.stats$N,summary.stats$ss,R.sq[,m],g,indices))
max.logML<-apply(logML,1,function(x) max(x))
log.denom<-(max.logML+log(rowSumsC(exp(logML-matrix(rep(max.logML,each=indices$M), ncol=indices$M, byrow=TRUE)))))
z<-exp(logML-matrix(rep(log.denom,each=indices$M), ncol=indices$M, byrow=T))
g<-((indices$J*summary.stats$N*sum(z*R.sq/g.R.sq))/(sum(z%*%pm)))-1
}
return(list(model.probs=z,g=g))
}


compute_modelprobs_globalEB_k<-function(model.weights,model,summary.stats,g.start,indices,max.iter){
g<-g.start

prior.weights<-matrix(rep(model.weights,each=indices$K),nrow=indices$K)
R.sq<-sapply(1:indices$M,function(m) compute_Rsq(model[[m]],summary.stats))
pm<-sapply(1:indices$M,function(m) ncol(model[[m]]))
for (t in 1:max.iter){
g.vec<-matrix(rep(g,each=indices$M), ncol=M, byrow=TRUE)
#g.vec<-t(matrix(rep(g,each=indices$K), ncol=indices$K, byrow=TRUE))
g.R.sq<-1-(g.vec/(1+g.vec))*R.sq
logML<-log(prior.weights)+sapply(1:indices$M, function(m) compute_logML_EM(model[[m]],summary.stats$N,summary.stats$ss,R.sq[,m],g[m],indices))
max.logML<-apply(logML,1,function(x) max(x))
log.denom<-(max.logML+log(rowSumsC(exp(logML-matrix(rep(max.logML,each=indices$M), ncol=indices$M, byrow=TRUE)))))
z<-exp(logML-matrix(rep(log.denom,each=indices$M), ncol=indices$M, byrow=T))
g[g<0]<-0
g<-((indices$J*summary.stats$N*rowSumsC(z*R.sq/g.R.sq))/((z%*%pm)))-1

#g<-sapply(1:M,function(m) ((indices$J*summary.stats$N*sum(z[,m]*R.sq[,m]/g.R.sq[,m]))/sum(z[,m]*pm[m]))-1)
}
return(list(model.probs=z,g=g))
}



compute_modelprobs_globalEB_mixture<-function(model.weights,model,summary.stats,g.start,indices,max.iter){
g<-g.start
prior.weights<-matrix(rep(model.weights,each=indices$K),nrow=indices$K)
R.sq<-sapply(1:indices$M,function(m) compute_Rsq(model[[m]],summary.stats))
pm<-sapply(1:indices$M,function(m) ncol(model[[m]]))
for (t in 1:max.iter){
g.R.sq<-1-(g/(1+g))*R.sq
logML<-log(prior.weights)+sapply(1:indices$M, function(m) compute_logML_EM(model[[m]],summary.stats$N,R.sq[,m],g,indices))
max.logML<-apply(logML,1,function(x) max(x))
log.denom<-(max.logML+log(rowSumsC(exp(logML-matrix(rep(max.logML,each=indices$M), ncol=indices$M, byrow=TRUE)))))
z<-exp(logML-matrix(rep(log.denom,each=indices$M), ncol=indices$M, byrow=T))
g<-((indices$J*summary.stats$N*sum(z*R.sq/g.R.sq))/sum(z%*%pm))-1
}
return(list(model.probs=z,g=g))
}

save.xlsx <- function (file, list.to.save)
  {
      require(xlsx, quietly = TRUE)
      objects <- list.to.save
      objnames <- names(objects)
      nobjects <- length(objects)
      for (i in 1:nobjects) {
          if (i == 1)
              write.xlsx(objects[[i]], file, sheetName = objnames[i])
          else write.xlsx(objects[[i]], file, sheetName = objnames[i],
              append = TRUE)
      }
      print(paste("Workbook", file, "has", nobjects, "worksheets."))
}
#######################################



#Function to generate summary stats for a given dataset (based on mean-centered data): LOO-CV
generate_summary_stats_loocv<-function(data,summary.stats,id){
#Compute response-specific summary statistic - sum by cell type/CpG and sum of squares by CpG
	#Define data corresonding to select id
	ystar<-subset(data,ID==id,select=c(CpGname,cell.type,response.c))

	#Decrement overall summary stats already calculated (ysum.ct and ss)
	ysum.ct.n<-summary.stats$ysum.ct[,cell.types,with=F]-dcast(ystar,CpGname~cell.type,value.var="response.c")[,cell.types,with=F]
	ss.n<-summary.stats$ss-ystar[,list(ss.n.1=sum(response.c^2)),by=list(CpGname)]$ss.n.1

	

	ystar<-dcast(ystar,CpGname~cell.type,value.var="response.c")
	output<-list(ystar=ystar,ysum.ct=ysum.ct.n,ss=ss.n,sample.var=summary.stats$sample.var)
	return(output)
}


#function to compute ML for a given cell specific model - conjugate prior with fixed variance scale (similar to normal FMM)
compute_ML<-function(X,summary.stats,prior,N0,indices){

	#Set up hyperparameters/indices
	N<-indices$N
	J<-indices$J
	beta0<-rep(0,indices$K)

	ysum.ct<-summary.stats$ysum.ct[,cell.types,with=F]
	ss<-summary.stats$ss
	p<-ncol(X)
	Sigma<-solve(N*t(X)%*%X+N0*diag(p))
	s<-as.matrix(ysum.ct)%*%X+N0*matrix(rep(beta0,each=p), ncol=p, byrow=TRUE)  #beta0=ybar
	A<-ss+p*N0*(beta0)^2-covmultiply((s%*%Sigma),s)
	if (prior=="informative"){
	#Informative prior on variance
	a<-2.5
	b<-0.5*summary.stats$sample.var
	logML<-(-0.5*N*J)*log(2*pi)+(0.5*p)*log(N0)+0.5*log(det(Sigma))+a*log(b)+lgamma(a+0.5*N*J)-lgamma(a)-(a+0.5*N*J)*log(b+0.5*A)
	}
	if (prior=="ref"){
	logML<-(-0.5*N*J)*log(2*pi)+(0.5*p)*log(N0)+0.5*log(det(Sigma))+lgamma(0.5*N*J)-(0.5*N*J)*log(0.5*A)
	}
	if (prior=="full ref"){
	Sigma<-solve(t(X)%*%X)
	s<-as.matrix(ybar.ct)%*%X
	A<-ss-N*covmultiply(s%*%Sigma,s)
	logML<-(-0.5*(N*J-p))*log(pi)-(0.5*p)*log(N)+0.5*log(det(Sigma))+lgamma(0.5*(N*J-p))-0.5*(J*N-p)*log(A)
	}
	return(exp(logML))	
}


#Function to compute ML for a given cell specific model - g prior
compute_ML_gprior<-function(X,N,J,ybar.ct,ss,a){
	p<-ncol(X)
	R.sq<-N*covmultiply(as.matrix(ybar.ct)%*%X%*%solve(t(X)%*%X)%*%t(X),as.matrix(ybar.ct))/ss
	ML<-compute_laplace_approx(1,J*N,p+a,R.sq)
	G.exp<-compute_laplace_approx(2,J*N,p+a+2,R.sq)/ML
	#return output as a data.frame
	return(R.sq)
}

#Function to compute ML for a given cell specific model - g prior with intercept based on SVD of X
compute_ML_gprior<-function(X,N,J,ybar.ct,ss,a){
	p<-ncol(X)
	U<-svd(scale(X,center=T,scale=F))$u[,1:(p-1)]
	R.sq<-N*covmultiply(as.matrix(ybar.ct)%*%U%*%t(U),as.matrix(ybar.ct))/ss
	ML<-compute_laplace_approx(1,J*N-1,p-1+a,R.sq)
	G.exp<-compute_laplace_approx(2,J*N-1,p-1+a+2,R.sq)/ML
	#return output as a data.frame
	return(list(ML=ML,g=G.exp,R.sq=R.sq))
}



#function to compute laplace approximation to marginal likelihood under g prior
compute_laplace_approx<-function(b,N,Q,R.sq){
out<-(-(N-Q)+(2*b-N)*(1-R.sq)-sqrt((((N-Q)+(2*b-N)*(1-R.sq))^2)-8*b*(2*b-Q)*(1-R.sq)))/(2*(2*b-Q)*(1-R.sq))
tau<-log(out)
sigma2.hat<-1/(-0.5*(N-Q)*exp(tau)/((1+exp(tau))^2)+0.5*N*exp(tau)*(1-R.sq)/((1+exp(tau)*(1-R.sq))^2))
h.mode<-b*tau+0.5*(N-Q)*log(1+exp(tau))-0.5*N*log(1+exp(tau)*(1-R.sq))
return(sqrt(2*pi)*sqrt(sigma2.hat)*exp(h.mode))
}

#Bayes FDR CpG selector function
bayes.FDR<-function(prob,alpha){
  K<-length(prob)
#sort 1-prob in increasing order
tmp<-sort.int(1-prob,index.return=T)
#find value of k whereby cumulative mean is less than alpha
return(names(which((cumsum(tmp$x)/(1:K))<=alpha)))
}

#compute posterior probabliity of each model
compute_model_probs<-function(ML,p,model.names,CpG.list){
	model.prob<-mixtureprob(ML,p)/matrix(ML%*%p,nrow(ML),ncol(ML))
	model.prob<-attach_names(model.prob,model.names,CpG.list)
	return(model.prob)

}

#generic function to attach column and row names to matrix object
attach_names<-function(x,col.names,row.names){
	colnames(x)<-col.names
	rownames(x)<-row.names
	return(x)
}