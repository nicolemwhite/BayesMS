rm(list=ls())
#Nicole White, 2016
#Supplementary R code for 'Accounting for cell lineage and sex effects in the identification of cell-specific DNA methylation using a Bayesian model selection algorithm'.
#This folder contains R functions and base script required to run the Bayesian model selection algorithm outlined in 'Methodology', in the main text of the paper.
#Code is set up for a single sex

#load R packages
library(data.table)

#Load sources files containing functions (requires Rcpp and inline)
source("Rcpp functions.R")
source("ML functions.R")

#load data: eg. load('methylation_data.RDS')
#object 'data' contains the following fields:
  #CpGname: CpG probe label
  #cell.type: purified cell subtype. For example: 'CD19B','CD4T','CD8T','Mono','Neu','NK'
  #beta.value: methylation beta.value by CpGname and cell.type; Note M.values are also accommodated (label 'M.value')

#Center data so that b0=0 (hyperparameter)
data.c<-center_methyln_data(subset(samples,dataset=="Reinius"),'beta.value')

#compute sufficient statistics for marginal likelihood calculation
summary.stats<-generate_summary_stats(data.c)

list2env(summary.stats[c('cell.types','CpG.list')],globalenv())

#load cell-specific models (provided as separate RDS file - See table 1 of paper)
load('cell dependent models.RDS')

#Define relevant indices
indices<-list(J=length(cell.types),K=length(CpG.list),M=length(model))


#set prior model probabilities
p<-rep(1/M,M)


#Run EM algorithm for optimise g and posterior model probabilities
#object 'model.run' is a list containing posterior model probabilities ($model.probs) and estimate of scaling factor g ($g)
model.run<-compute_modelprobs_globalEB(p,model,summary.stats,100,indices,50)
model.run$model.probs<-attach_names(model.run$model.probs,names(model),CpG.list)

#Other functions based on model selection output
#Apply 5% Bayes FDR to each marker panel - output is list of CpGnames
FDR.markers<-lapply(1:M,function(m) bayes.FDR(model.out[,m],K,0.05))

#Function to compute model estimates (mu,sigma2) for select cell specific model
#Output is a data.table with following fields: 
#CpGname: CpG probe label
#partition: cell-specific partition (last is reference) 
#mean.estimate: expected methylation by CpGname and partition (mu)
#var.estimate: estimated variance by CpGname and partition (Eq 2 in 'Methodology' section of paper)
model.estimates<-lapply(1:M,function(m) compute_beta_post(summary.stats,model[[m]],model.out$g,indices,CpG.list))


