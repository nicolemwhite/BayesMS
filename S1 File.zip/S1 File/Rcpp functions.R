library(Rcpp)
library(inline)
cppFunction('
  NumericVector covmultiply( NumericMatrix m , NumericMatrix v)
 {
   NumericVector out(m.nrow());
   for (int i = 0; i < m.nrow(); i++){
	double total = 0;
   for (int j = 0; j < m.ncol(); j++){ 
	total += m(i,j)*v(i,j);
   }
	out[i] = total;
   }
   return out ;
   }
 ')

cppFunction('
  NumericMatrix mixtureprob( NumericMatrix m , NumericVector v)
 {
   NumericMatrix out(m.nrow(),m.ncol());
   for (int j = 0; j < m.ncol(); j++){
   for (int i = 0; i < m.nrow(); i++){ 
   out(i,j)=m(i,j) * v(j) ;
   }
   }
   return out ;
   }
 ')

cppFunction('
            NumericMatrix vecbymat(NumericVector v, NumericMatrix m)
            {
            NumericMatrix out(m.nrow(),m.ncol());
            for (int i = 0; i < m.nrow(); i++){             
            for (int j = 0; j < m.ncol(); j++){
            out(i,j)=v(i)*m(i,j) ;
            }
            }
            return out ;
            }
            ')

cppFunction('
            NumericMatrix vecplusmat(NumericVector v, NumericMatrix m)
            {
            NumericMatrix out(m.nrow(),m.ncol());
            for (int i = 0; i < m.nrow(); i++){             
            for (int j = 0; j < m.ncol(); j++){
            out(i,j)=v(i)+m(i,j) ;
            }
            }
            return out ;
            }
            ')

cppFunction('NumericVector rowSumsC(NumericMatrix x) {
  int nrow = x.nrow(), ncol = x.ncol();
  NumericVector out(nrow);

  for (int i = 0; i < nrow; i++) {
    double total = 0;
    for (int j = 0; j < ncol; j++) {
      total += x(i, j);
    }
    out[i] = total;
  }
  return out;
}')


cppFunction('NumericMatrix random_IG(int M, NumericVector A, NumericVector B) {
  using namespace Rcpp; 

  int K = A.length();
  NumericMatrix out(K,M);

  RNGScope scope;
  for (int i = 0; i < K; i++) {
    for (int j = 0; j < M; j++) {
      out(i,j) = ::Rf_rgamma(A(i),1.0/B(i));
    }
  }
  return out;
}')

cppFunction('NumericMatrix apply_cumsum_row(NumericMatrix m) {
     for (int i = 0; i < m.nrow(); ++i) {
         for (int j = 1; j < m.ncol(); ++j) {
             m(i, j) += m(i, j-1);
         }
     }
     return m;
 }');

cppFunction('NumericVector colSumsC(NumericMatrix x) {
  int nrow = x.nrow(), ncol = x.ncol();
  NumericVector out(ncol);

  for (int j = 0; j < ncol; j++) {
    double total = 0;
    for (int i = 0; i < nrow; i++) {
      total += x(i, j);
    }
    out[j] = total;
  }
  return out;
}')